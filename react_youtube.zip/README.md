# Getting Started with Create React App

## react start

npx create-react-app [이름]

## axios 설치

npm i axios

## router 설치 (가상의 주소 만들어줌)

npm i react-router-dom

## react-player 설치

npm i react-player

## scss 설치

npm i node-sass

##react icon 설치
npm install react-icons -save
https://react-icons.github.io/react-icons/icons?name=ai
