import React from "react";

const AsideConts = () => {
  return <aside id="aside">aside</aside>;
};

export default AsideConts;
